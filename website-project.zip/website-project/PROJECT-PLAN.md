# Part 1: Building the Foundation — Project Plan

Since no specific niche was given, this plan is built around a **personal portfolio site**
(a common first-project choice) — swap the specifics below for your own if your
project is different.

## 1. Plan Your Project

**Target audience:** People who might hire or collaborate with you — recruiters,
potential clients, other developers/designers browsing your work.

**Goals:**
- Make a strong first impression within 5 seconds of landing on the page.
- Show 3–5 real examples of work, not a wall of text about yourself.
- Make it dead simple to get in touch (one clear contact path).

**Project plan (pages/sections):**
1. Home (hero) — who you are, what you do, one strong visual.
2. Work/Projects — a short list of pieces, each with a one-line result, not just a description.
3. About — brief, written like a person, not a resume.
4. Contact — a direct method (email link or short form), no gatekeeping.

## 2. Research and Content Gathering

Before writing any HTML, gather:
- Real project examples (screenshots, links, write-ups) — placeholders slow you down later.
- A short bio (2–3 sentences, written in your own voice).
- A professional-looking photo or avatar, if you're comfortable including one.
- Any existing brand colors/fonts you want to keep, or note that you're starting fresh.

## 3. Create the HTML Structure

Basic semantic skeleton (already built for you in `index.html`):
```
<header>   → site name/logo + <nav>
<nav>      → links to Work, About, Contact
<main>     → hero section, work section, about section, contact section
<footer>   → copyright, social links
```

## 4. Organise Your Files

```
website-project/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── images/        (your photos, screenshots, icons)
└── assets/        (resume PDF, fonts, other downloadable files)
```

Keep this structure from day one — reorganising a live site later just breaks
your image/link paths for no benefit.
